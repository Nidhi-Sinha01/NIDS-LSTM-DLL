# Intrusion-Detection-using-Machine-Learning-on-NSL--KDD-dataset
Pre-processing NSL-KDD dataset using Data mining techniques. Algorithm written in python to detect the attacks in NSL KDD dataset.
